#include <stdio.h>

int main()
{
printf("Potatoes are very good and amazing for you . Tostitios should be enjoyed in the car and on a aplane. Pop tarts are very good and amzaing for planes as they provide fuel\n");
}
