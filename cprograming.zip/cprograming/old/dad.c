#include <stdio.h>


int main ()
{

    char name[20];

    char c;

    
    //make sure too add 1 to the number in the []
    //this accounts for \0, or treminating number
    printf("Hello! Whats your name? \n");
    scanf("%s", name);
    printf("Oh! Nice to meet you %s, I'm Dad! \n", name);








}