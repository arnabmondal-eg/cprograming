#include <math.h>
#include <stdio.h>

int main()
{

    int number = 0;
    double squareRoot = 0;


    printf("Enter a number: ");
    scanf("%d", &number);


    squareRoot = sqrt(number);

    printf("Square root of %d = %lf \n", number, squareRoot);
//what is %lf
//why do i need math.h
//this was weird







}