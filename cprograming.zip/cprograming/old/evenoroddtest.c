#include <stdio.h>


int main()
{
    int answer = 0;

    






    printf("Enter Number \n");
    scanf("%d", &answer);
    if(answer % 2 == 0 )
        {
            printf("Your Number is Even \n");
        }
    else
        {
            printf("Your Number is Odd \n");
        }




}